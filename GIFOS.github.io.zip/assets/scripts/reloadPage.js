logo.addEventListener("click", ()=> {
    location.reload();
  });
  